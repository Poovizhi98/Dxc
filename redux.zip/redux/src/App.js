import React from 'react';
import logo from './logo.svg';
import './App.css';
import UsersComponent from './component/UsersComponent';
import store from '../src/component/store';
import {Provider} from 'react-redux';

function App() {
  return (
    <Provider store={store}>
    <div className="App">
      <UsersComponent></UsersComponent>
    </div>
    </Provider>
  );
}

export default App;
