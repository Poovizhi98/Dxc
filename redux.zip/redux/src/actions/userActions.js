import {FETCH_USER, ADD_MODAL,CLOSE_MODAL,SUBMIT_MODAL} from './userTypes';
import UserService from '../services/UserService';

export const fetchUser=()=>dispatch=>{
    console.log("Fetching users")

    UserService.getUser().then(res=>{
        dispatch({
            type:FETCH_USER,
            payload:res.data
        })
    })
}

export const doaddModal=(user)=>({
        type:ADD_MODAL,
        payload:user
    })
export const docloseModal=()=>({
        type:CLOSE_MODAL,
        payload:false
})
export const dosubmit=(event)=>({
    type:SUBMIT_MODAL,
    payload:event
})



