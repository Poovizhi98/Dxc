export const FETCH_USER = 'FETCH_USER';
export const ADD_MODAL='ADD_MODAL';
export const CLOSE_MODAL='CLOSE_MODAL';
export const SUBMIT_MODAL='SUBMIT_MODAL';