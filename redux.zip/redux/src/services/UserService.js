import axios from 'axios'

class UserService {
        getUser(){
            return axios.get(`http://localhost:3001/users`)
        }        
        addUser(user){
            return  axios.post(`http://localhost:3001/users`,user)    
        }
        updateUser(user,userId){
            return  axios.put(`http://localhost:3001/users/${userId}`,user)  
              
}
}

export default new UserService()