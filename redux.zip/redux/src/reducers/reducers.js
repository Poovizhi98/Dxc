import {FETCH_USER} from '../actions/userTypes';
import {ADD_MODAL,CLOSE_MODAL,SUBMIT_MODAL} from '../actions/userTypes';
import UserService from '../services/UserService';

const initialState={
    users:[],
    showModal:false,
    btn:'',
    status:'',
    name:'',
    username:'',
    phone:'',
    email:'',
    editid:''
}

const UserReducers=(state=initialState,action)=>{
        switch(action.type){
            case FETCH_USER:
                return{
                    ...state,
                    users:action.payload
                }
            case ADD_MODAL:
                if(action.payload){
                return{
                    ...state,
                    showModal:true,
                    name:action.payload.name,
                    username:action.payload.username,
                    phone:action.payload.phone,
                    email:action.payload.email,
                    editid:action.payload.id,
                    btn:'Edit',
                    status:2,
                    disable:true
                }
            }
                else{
                    return{
                    ...state,
                    showModal:true,
                    name:'',
                    username:'',
                    phone:'',
                    email:'',
                    btn:'Save',
                    status:1,
                    disable:false
                    }
                }
            case CLOSE_MODAL:
                return{
                    ...state,
                    showModal:action.payload
                }
            case SUBMIT_MODAL:
                if(state.status===1){
                    UserService.addUser(action.payload)
                }
                else{
                    UserService.updateUser(action.payload,state.editId)
                }
                return{
                    ...state
                }
            default:
                return state
        }
}


export default UserReducers
