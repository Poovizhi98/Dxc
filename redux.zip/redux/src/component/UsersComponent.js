import React, { Component } from 'react';
import usericon from '../images/usericon.jpg';
import usericon1 from '../images/usericon1.jpg';
import {connect} from 'react-redux';
import {fetchUser,doaddModal, docloseModal} from '../actions/userActions';
import 'bootstrap/dist/css/bootstrap.min.css';
import AddModal from './AddModal';

class UsersComponent extends Component{
    componentDidMount(){
       this.refresh();
    }

    refresh(){
        this.props.fetchUser();
        console.log(this.props);
    }

    AddEditModal=(user)=>{
        console.log("Add MOdal Clicked")
        this.props.addModal(user);
    }

    closeModal=()=>{
        console.log("Close Modal clicked");
        this.props.closeModal();
    }
    render(){

        const { users } = this.props;
    console.log(this.props);

        return(
            <div>
            <div className="header" id="navbar">
           <img id="image1" src={usericon1} alt="img"/>
           </div>
          <br/> 
           <div id="usericon" className="glyphicon glyphicon-user">Users</div>
              
          <div className="container" >
            <span  id="plus"  className="glyphicon glyphicon-plus"
            onClick={()=>this.AddEditModal()}>NewUser
            </span>
           <span id="search"><div>Filter:</div>
           <input type="text" 
           //onChange={this.handleSearch}
           >
            </input></span> 
          </div>
       
             <AddModal show={this.props.showModal}
            onHide={this.closeModal} 
          refresh={this.refresh} >
            
            </AddModal> 
           
         <div className="container"> 
          <div className="users">        
          {users.sort((a,b)=>b.id-a.id).map((user,index)=>(
              <div className="card" key={index}>
          
              <div id="head" className="header">
              <div className="container">
              <h5 className="card-title" id="username">{user.username}</h5>
             
               <span id="button" className="glyphicon glyphicon-edit"  
                onClick={()=>this.AddEditModal(user)}>
               </span>            
              </div>
              </div>
              <div className="card-body">
            
              <img id="image" src={usericon} className="card-img-top" alt="img"/>
               <p className="card-text" id="details">{user.name}
               <br/>{user.email}<br/>{user.phone}</p>
               </div>
              
          </div>
          
          ))} 
          </div> 
          </div>
          </div>         
             
           
        )
        }
    }
    
const mapStatetoProps=state=>({
    users:state.userReducers.users,
    showModal:state.userReducers.showModal
})

const mapDispatchToProps=dispatch=>{
    return{
        fetchUser:()=>dispatch(fetchUser()),
        addModal:(user)=>dispatch(doaddModal(user)),
        closeModal:()=>dispatch(docloseModal())
    }

    
}

export default connect(mapStatetoProps,mapDispatchToProps)(UsersComponent);