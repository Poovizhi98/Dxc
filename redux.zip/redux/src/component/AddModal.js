import React, { Component } from 'react';
import {Modal,Button} from 'react-bootstrap';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import {connect} from 'react-redux';
import {dosubmit} from '../actions/userActions';


class AddModal extends Component {
  
   onSubmit=(event)=>{
    console.log(event)
    this.props.submitModal(event);
   }


validateForm(values){
  let errors={}
  var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
  if(!values.username)
  {
      errors.username='Enter Username'
  }
  else if(!values.name){
      errors.name='Enter Name'
  }
  else if(!isNaN(values.name)){
      errors.name='Name should not be integer'
  }
  else if(!values.email){
      errors.email='Enter Email'
  }
  else if(reg.test(values.email) == false){
    errors.email='Enter a valid emailId'
  }
  else if(!values.phone){
      errors.phone='Enter Phone'
  }
  return errors
}

    render() {

        let {username,name,email,phone}=this.props
        return (
            <div>
            
            <Modal
      {...this.props}
      size="lg"
      aria-labelledby="contained-modal-title-vcenter" centered>
      <Modal.Header closeButton>
        <Modal.Title id="contained-modal-title-vcenter" className="addUsertitle">
          Add User
        </Modal.Title>
      </Modal.Header>
       <Modal.Body>
       
      
       <div className="container"> 
             <Formik initialValues={{username,name,email,phone}}
             enableReinitialize={true}
             onSubmit={this.onSubmit} validateOnChange={false}
             validateOnBlur={false} 
             validate={this.validateForm}>
            <Form>
                <ErrorMessage name="username" component="div" className="alert alert-warning"></ErrorMessage>
                <fieldset className="form-group">
                    <label>UserName</label>
                   
                    <Field className="form-control" type="text" 
                    name="username" disabled={this.props.disable}></Field>
                   
                </fieldset>

                <ErrorMessage name="name" component="div" className="alert alert-warning"></ErrorMessage>
                <fieldset className="form-group">
                    <label> Name</label>
                    <Field className="form-control" type="text"
                    name="name" ></Field>
                </fieldset>
                <ErrorMessage name="email" component="div" className="alert alert-warning"></ErrorMessage>
                <fieldset className="form-group">
                    <label>Email</label>
                    <Field className="form-control" type="text" 
                    name="email" ></Field>
                </fieldset>
                <ErrorMessage name="phone" component="div" className="alert alert-warning"></ErrorMessage>
                <fieldset className="form-group">
                    <label>Phone Number</label>
                    <Field className="form-control" type="text" 
                    name="phone"></Field>
                </fieldset>
                <button className="btn btn-success" type="submit">{this.props.btn}
                </button>
            </Form>
        </Formik>
            </div>
        
      </Modal.Body> 
      <Modal.Footer>
         <Button variant='danger' onClick={this.props.onHide}>Close</Button> 
      </Modal.Footer>
    </Modal>
 
    
            </div>
        );
    }
}

const mapStateToProps=(state)=>{
    return{
    username:state.userReducers.username,
    name:state.userReducers.name,
    email:state.userReducers.email,
    phone:state.userReducers.phone,
    btn:state.userReducers.btn,
    status:state.userReducers.status,
    editid:state.userReducers.editid,
    disable:state.userReducers.disable
}
}

const mapDispatchToProps=(dispatch)=>{
    return{
         submitModal:(event)=>dispatch(dosubmit(event)),
    }
}


export default connect(mapStateToProps,mapDispatchToProps)(AddModal);