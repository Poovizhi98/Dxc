import React, { Component } from 'react';
import usericon from '../images/usericon.jpg';
import usericon1 from '../images/usericon.jpg';
import AddModal from './AddModal';
import 'bootstrap/dist/css/bootstrap.min.css';
import UserService from '../services/UserService';

class UserList extends Component {
    constructor(props) {
        super(props);
    this.state={
       users:[],
       users1:[],
       showModal:false,
       editid:'',
       editname:'',
       editusername:'',
       editphone:'',
       editemail:'',
       status:'',
       btn:''
    }  
    this.handleSearch=this.handleSearch.bind(this); 
    }

    refresh=()=>{
        UserService.getUser()
       //fetch('https://jsonplaceholder.typicode.com/users') 
       //.then(res=>res.json())
       .then(res=>{
           console.log(res)
        
           this.setState({
               
               users:res.data,
               users1:res.data
           })
            console.log(this.state.users)
       })
    }
    
    componentDidMount(){
      this.refresh();
    }
    handleSearch(event){
        let filteredSearch=this.state.users1.filter(
            (user)=>{
                return user.username.indexOf(event.target.value)!==-1
            }
         );
         this.setState({
             users:filteredSearch
         })
         if(event.target.value.length===0){
             this.setState({
                 users:this.state.users1
             })
         }
    }

    onClickClose=()=>{
        this.setState({showModal:false})
    }
    
    render() {
        const {users}=this.state
       
        let handleClose=()=> this.onClickClose()
        
        return (
          
            <div>
             <div className="header" id="navbar">
             <img id="image1" src={usericon1} alt="img"/>
             </div>
            <br/>
            <div id="usericon" className="glyphicon glyphicon-user">Users</div>
                
            <div className="container" >
              <span  id="plus"  className="glyphicon glyphicon-plus"
              onClick={()=>this.setState({showModal:true,status:'1',btn:'Save'})}>NewUser
              </span>
             <span id="search"><div>Filter:</div>
             <input type="text" onChange={this.handleSearch}>
              </input></span> 
            </div>
        
              <AddModal show={this.state.showModal}
              onHide={handleClose} refresh={this.refresh} editid={this.state.editid}
              status={this.state.status} btn={this.state.btn} editname={this.state.editname}
              editusername={this.state.editusername} editemail={this.state.editemail} editphone={this.state.editphone}>
              </AddModal>
             
           <div className="container">
            <div className="users">        
            {users.sort((a,b)=>b.id-a.id).map((user,index)=>(
                <div className="card" key={index}>
            
                <div id="head" className="header">
                <div className="container">
                <h5 className="card-title" id="username">{user.username}</h5>
               
                <span id="button" className="glyphicon glyphicon-edit" 
                  onClick={()=>this.setState({showModal:true,status:'2',btn:'Edit',editid:user.id
                  ,editname:user.name,editusername:user.username,editemail:user.email,editphone:user.phone})} >
                 </span>
                
                </div>
                </div>
                <div className="card-body">
              
                <img id="image" src={usericon} className="card-img-top" alt="img"/>
                 <p className="card-text" id="details">{user.name}
                 <br/>{user.email}<br/>{user.phone}</p>
                 </div>
                
            </div>
            
            ))} 
            </div> 
            </div>
            </div>         
           
        );
    }
}

export default UserList;