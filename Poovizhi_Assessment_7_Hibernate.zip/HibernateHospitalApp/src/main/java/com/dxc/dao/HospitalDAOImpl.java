package com.dxc.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.dxc.model.Hospital;
import com.dxc.util.HibernateUtil;

public class HospitalDAOImpl implements HospitalDAO{
	
	SessionFactory sf=HibernateUtil.getSessionFactory();

	public Hospital getHospital(int hospitalId) {
		Session session=sf.openSession();
		Transaction transaction=session.beginTransaction();
		Hospital hospital=(Hospital) session.get(Hospital.class, hospitalId);
		transaction.commit();
		session.close();
		return hospital;
	}

	public List<Hospital> getAllHospital() {
		Session session=sf.openSession();
		Query query=session.createQuery("from Hospital");
		return query.list();
	}

	public void addHospital(Hospital hospital) {
		Session session=sf.openSession();
		Transaction transaction=session.beginTransaction();
		session.save(hospital);
		transaction.commit();
		session.close();
		System.out.println(hospital.getHospitalName()+" saved successfully");
	}

	public void deleteHospital(int hospitalId) {
		Session session=sf.openSession();
		Transaction transaction=session.beginTransaction();
		Hospital hospital=(Hospital) session.get(Hospital.class, hospitalId);
		session.delete(hospital);
		transaction.commit();
		session.close();
	}

	public void updateHospital(Hospital hospital) {
		Session session=sf.openSession();
		Transaction transaction=session.beginTransaction();
		session.update(hospital);
		transaction.commit();
		session.close();
	}

	public boolean isHospitalExists(int hospitalId) {
		Session session=sf.openSession();
		Hospital hospital=(Hospital) session.get(Hospital.class, hospitalId);
		if(hospital==null)
		   return false;
		else
		   return true;
	}

	public List<Hospital> getAllHospital(String hospitalName) {
		Session session=sf.openSession();
        Query query=session.getNamedQuery("findHospitalByName");
        query.setString("hoName",hospitalName);
		return query.list();
	}
	
//	public List<Hospital> getAllMovies(String MovieName) {
//		Session session=sf.openSession();
//        Query query=session.getNamedQuery("findMoviesByName");
//        query.setString("moName",MovieName);
//		return query.list();
//	}
//

}
