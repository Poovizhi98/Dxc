package com.dxc.dao;

import java.util.List;

import com.dxc.model.Hospital;

public interface HospitalDAO {
	public Hospital getHospital(int hospitalId);
	public List<Hospital> getAllHospital();
	public void addHospital(Hospital hospital);
	public void deleteHospital(int hospitalId);
	public void updateHospital(Hospital hospital);
	public boolean isHospitalExists(int hospitalId);
	public List<Hospital> getAllHospital(String hospitalName);
	//public List<Hospital> searchHospital(String HospitalName);

}
