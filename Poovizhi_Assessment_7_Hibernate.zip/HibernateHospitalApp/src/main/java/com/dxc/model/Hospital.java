package com.dxc.model;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OrderColumn;



@NamedQueries({
	@NamedQuery(
			name="findHospitalByName",
			query="from Hospital h where h.hospitalName=:hoName"
			)
})

@Entity
public class Hospital {
	@Id
	private int hospitalId;
	@Column(name="HospitalName")
	private String hospitalName;
	@Column(name="Fees")
	private int fees;
	
	@ElementCollection
    @OrderColumn(name = "hospitalDetails")
    private Set<HospitalDetails> details;

	
	public Hospital() {
		super();
	}
	

	public Hospital(int hospitalId, String hospitalName, int fees, Set<HospitalDetails> details) {
		super();
		this.hospitalId = hospitalId;
		this.hospitalName = hospitalName;
		this.fees = fees;
		this.details = details;
	}
	
	public int getHospitalId() {
		return hospitalId;
	}

	public void setHospitalId(int hospitalId) {
		this.hospitalId = hospitalId;
	}

	public String getHospitalName() {
		return hospitalName;
	}

	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}

	public int getFees() {
		return fees;
	}

	public void setFees(int fees) {
		this.fees = fees;
	}

	public Set<HospitalDetails> getDetails() {
		return details;
	}

	public void setDetails(Set<HospitalDetails> details) {
		this.details = details;
	}

	@Override
	public String toString() {
		return "Hospital [hospitalId=" + hospitalId + ", hospitalName=" + hospitalName + ", fees=" + fees + ", details="
				+ details + "]";
	}
	

	
}
