package com.dxc.dao;

import java.util.HashSet;
import java.util.List;
import java.util.Set;


import com.dxc.model.Hospital;
import com.dxc.model.HospitalDetails;


import junit.framework.TestCase;

public class HospitalDAOImplTest extends TestCase {
HospitalDAOImpl daoImpl;
	protected void setUp() throws Exception {
		super.setUp();
		daoImpl=new HospitalDAOImpl();
	}
	

	public void testgetHospital() {
		HospitalDetails details1=new HospitalDetails("Manipal", "Salem");
		Set<HospitalDetails> alldetails=new HashSet<HospitalDetails>();
    	alldetails.add(details1);
    	Hospital doctor = new Hospital(113,"Sam", 10000000, alldetails);
    	daoImpl.addHospital(doctor);
		Hospital doctor2=daoImpl.getHospital(112);
		assertNotNull(doctor2);
		daoImpl.deleteHospital(113);
	}

	public void testgetAllHospital() {
		int size1=daoImpl.getAllHospital().size();
		HospitalDetails details1=new HospitalDetails("St.Johns", "Mettur");
		Set<HospitalDetails> alldetails=new HashSet<HospitalDetails>();
    	alldetails.add(details1);
    	Hospital doctor = new Hospital(213,"Kavya", 4747748, alldetails);
    	daoImpl.addHospital(doctor);
		int size2=daoImpl.getAllHospital().size();
		assertNotSame(size2, size1);
		daoImpl.deleteHospital(213);
	}

	public void testaddHospital() {
		int size1=daoImpl.getAllHospital().size();
		HospitalDetails details1=new HospitalDetails("St.Johns", "Mettur");
		Set<HospitalDetails> alldetails=new HashSet<HospitalDetails>();
    	alldetails.add(details1);
    	Hospital doctor = new Hospital(313,"Kousalya", 4747748, alldetails);
    	daoImpl.addHospital(doctor);
		int size2=daoImpl.getAllHospital().size();
		assertNotSame(size2, size1);
		daoImpl.deleteHospital(313);
	}

	public void testdeleteHospital() {
		HospitalDetails details1=new HospitalDetails("St.Johns", "Mettur");
		Set<HospitalDetails> alldetails=new HashSet<HospitalDetails>();
    	alldetails.add(details1);
    	Hospital doctor = new Hospital(413,"Sharmila", 4747748, alldetails);
    	daoImpl.addHospital(doctor);
		int size1=daoImpl.getAllHospital().size();
		daoImpl.deleteHospital(413);
		int size2=daoImpl.getAllHospital().size();
		assertEquals(size2+1, size1);
	}

	public void testupdateHospital() {
		HospitalDetails details1=new HospitalDetails("St.Johns", "Mettur");
		Set<HospitalDetails> alldetails=new HashSet<HospitalDetails>();
    	alldetails.add(details1);
    	Hospital doctor = new Hospital(813,"Sharmila", 4747748, alldetails);
    	daoImpl.addHospital(doctor);
		List <Hospital> alldoctors=daoImpl.getAllHospital();
		HospitalDetails details2=new HospitalDetails("St.Johns", "Mettur");
		Set<HospitalDetails> alldetails1=new HashSet<HospitalDetails>();
    	alldetails1.add(details2);
    	Hospital doctor1 = new Hospital(813,"Kavya", 1234567, alldetails1);
    	daoImpl.updateHospital(doctor1);
		List <Hospital> alldoctors2=daoImpl.getAllHospital();
		assertNotSame(alldoctors2, alldoctors);
		daoImpl.deleteHospital(813);
	}


//	public void testgetAllHospital() {
//		HospitalDetails details1=new HospitalDetails("Manipal", "Salem");
//		Set<HospitalDetails> alldetails=new HashSet<HospitalDetails>();
//    	alldetails.add(details1);
//    	Hospital doctor = new Hospital(812,"Sam", 10000000, alldetails);
//    	daoImpl.addHospital(doctor);
//    	Hospital doctor2=daoImpl.getAllHospital("Sam");
//		assertNotNull(doctor2);
//	}
	public void testisHospitalExists() {
		HospitalDetails details1=new HospitalDetails("St.Johns", "Mettur");
		Set<HospitalDetails> alldetails=new HashSet<HospitalDetails>();
    	alldetails.add(details1);
    	Hospital doctor = new Hospital(5513,"Poovizhi", 4747748, alldetails);
    	daoImpl.addHospital(doctor);
		assertEquals(true, daoImpl.isHospitalExists(5512));
		daoImpl.deleteHospital(5513);
	}
	public void testisHospitalExists2() {
		HospitalDetails details1=new HospitalDetails("St.Johns", "Mettur");
		Set<HospitalDetails> alldetails=new HashSet<HospitalDetails>();
    	alldetails.add(details1);
    	Hospital doctor = new Hospital(6713,"Poovizhi", 4747748, alldetails);
    	daoImpl.addHospital(doctor);
    	daoImpl.deleteHospital(6712);
		assertEquals(false, daoImpl.isHospitalExists(6713));
	}
}
