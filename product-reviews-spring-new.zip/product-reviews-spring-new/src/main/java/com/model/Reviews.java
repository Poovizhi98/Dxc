package com.model;


import org.springframework.data.annotation.Id;

public class Reviews {
	@Id
    private int reviewId;
    private String reviews;
    private int rating;
    
	public Reviews() {
		super();
	}
	public Reviews(int reviewId, String reviews, int rating) {
		super();
		this.reviewId = reviewId;
		this.reviews = reviews;
		this.rating = rating;
	}
	
		public int getReviewId() {
		return reviewId;
	}
	public void setReviewId(int reviewId) {
		this.reviewId = reviewId;
	}
	public String getReviews() {
		return reviews;
	}
	public void setReviews(String reviews) {
		this.reviews = reviews;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	
	
	@Override
	public String toString() {
		return "Reviews [reviewId=" + reviewId + ", reviews=" + reviews + ", rating=" + rating + "]";
	}
	
	
    
}
