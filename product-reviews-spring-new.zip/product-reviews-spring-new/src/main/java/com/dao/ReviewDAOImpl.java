package com.dao;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import com.model.Product;
import com.model.Reviews;
import com.mongodb.WriteResult;
import com.service.ProductService;
import com.service.ReviewService;

@Repository
public class ReviewDAOImpl implements ReviewDAO {

	@Autowired
	ProductService productService;
	ReviewService reviewService;
	@Autowired
	MongoTemplate mongotemplate;
	ReviewDAO reviewDAO;
	@Override
	public boolean addReviews(int productId,Reviews review) {
		// TODO Auto-generated method stub
		Product product=productService.getProduct(productId);
		System.out.println(product);
		//List<Reviews> r=(List<Reviews>) product.getReviews();
		//r.add(review);
		product.getReviews().add(review);
		mongotemplate.save(product);
		//mongotemplate.save(review);
		return false;
	}
	
	@Override
	public Reviews getReviews(int productId,int reviewId) {
		Product product=productService.getProduct(productId);
		System.out.println(product);
		List<Reviews> r=(List<Reviews>) product.getReviews();
		System.out.println(r);
		for(Reviews x:r) {
			if(x.getReviewId()==reviewId) {
				return x;
			}
		}
		return null;
	}
	 @Override
	    public boolean isReviewExists(int productId, int reviewId) {
	        Product product=productService.getProduct(productId);
	        System.out.println(product);
	        List<Reviews> r= (List<Reviews>) product.getReviews();
	        for(Reviews x:r) {
	            if(x.getReviewId()==reviewId) {
	                return true;
	            }
	        }
	        return false;
	    }
	@Override
	public boolean deleteReviews(int productId,int reviewId)  {
		// TODO Auto-generated method stub
		Product product=productService.getProduct(productId);
        List<Reviews> r= (List<Reviews>) product.getReviews();
        for(Reviews x:r) {
            if(x.getReviewId()==reviewId) {
                mongotemplate.remove(x);
                return true;
            }
            mongotemplate.save(product);
        }
        return false;
	}
	 @Override
	    public boolean updateReviews(int productId, Reviews review) {
	        Query query=new Query();
	        query.addCriteria(Criteria.where("productid").is(productId).and("reviewId").is(review.getReviewId()));
	        Update update=new Update();
	        update.set("reviews.reviews",review.getReviews());
	        update.set("reviews.rating",review.getRating());
	        WriteResult writeResult=mongotemplate.updateFirst(query,update,Product.class);
	        System.out.println(writeResult);
	        int rowsAffected=writeResult.getN();
	        if(rowsAffected==0)
	            return false;
	        else
	            return true;
	    }
	@Override
	public List<Reviews> getAllReviews(int productId)  {
		Product product=productService.getProduct(productId);
		List<Reviews> r=(List<Reviews>) product.getReviews();
		return r;
	}
	

}
