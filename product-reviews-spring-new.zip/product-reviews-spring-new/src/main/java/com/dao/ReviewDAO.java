package com.dao;

import java.util.List;

import com.model.Product;
import com.model.Reviews;

public interface ReviewDAO {
	public boolean addReviews(int productId,Reviews review);
    public Reviews getReviews(int productId,int reviewId);
    public boolean deleteReviews(int productId,int reviewId);
    public boolean updateReviews(int productId,Reviews review);
    public List<Reviews> getAllReviews(int productId);
	boolean isReviewExists(int productId, int reviewId);
     
}
