package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.ReviewDAO;
import com.model.Product;
import com.model.Reviews;

@Service
public class ReviewServiceImpl implements ReviewService {

	@Autowired
	ReviewDAO reviewDAO;
	@Override
	public boolean addReviews(int productId,Reviews review) {
		// TODO Auto-generated method stub
		return reviewDAO.addReviews(productId,review);
	}
	@Override
	public Reviews getReviews(int productId,int reviewId) {
		// TODO Auto-generated method stub
		return reviewDAO.getReviews(productId,reviewId);
	}
	@Override
	public boolean isReviewExists(int productId,int reviewId) {
		// TODO Auto-generated method stub
		return reviewDAO.isReviewExists(productId,reviewId);
	}
	@Override
	public boolean deleteReviews(int productId,int reviewId) {
		// TODO Auto-generated method stub
		return reviewDAO.deleteReviews(productId,reviewId);
	}
	@Override
	public boolean updateReviews(int productId,Reviews review) {
		// TODO Auto-generated method stub
		return reviewDAO.updateReviews(productId,review);
	}
	@Override
	public List<Reviews> getAllReviews(int productId) {
		// TODO Auto-generated method stub
		return reviewDAO.getAllReviews(productId);
	}
	
	
}
