package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.model.Product;
import com.model.Reviews;
import com.service.ProductService;
import com.service.ReviewService;

@RestController
@RequestMapping("product")
@CrossOrigin(origins= {"http://localhost:3000","http://localhost:4200"})
public class ReviewController {
	
	@Autowired
	ProductService productService;

	@Autowired
	ReviewService reviewService;
	
	@GetMapping("/{productId}/reviews/{reviewId}")
	public ResponseEntity<Reviews> getReview(@PathVariable("productId")int productId,@PathVariable("reviewId")int reviewId) {
		System.out.println("Get Reviews called "+reviewId);
		Reviews review=new Reviews();
		if(reviewService.isReviewExists(productId,reviewId))
		{
		review=reviewService.getReviews(productId, reviewId);
		return new ResponseEntity<Reviews>(review,HttpStatus.OK);
		}
		else {
			return new ResponseEntity<Reviews>(review,HttpStatus.NO_CONTENT);
		}
	}

	@GetMapping("/{productId}/reviews")
	public ResponseEntity<List<Reviews>> getAllReviews(@PathVariable("productId")int productId) {
		System.out.println("Get All reviews called");
		List<Reviews>allreviews= reviewService.getAllReviews(productId);
		return new ResponseEntity<List<Reviews>>(allreviews,HttpStatus.OK);
	}
	
	@PostMapping("/{productId}/reviews")
	public ResponseEntity<Reviews> saveReviews(@PathVariable("productId")int productId,@RequestBody Reviews review) {
		System.out.println("Saving Products called");
		if(reviewService.isReviewExists(productId,review.getReviewId()))
		{
			return new ResponseEntity<Reviews>(HttpStatus.CONFLICT);
		}
		else {
			reviewService.addReviews(productId,review);
			return new ResponseEntity<Reviews>(HttpStatus.CREATED);
		 
		}
	}
	
	//Deleting reviews
	@DeleteMapping("/{productId}/reviews/{reviewId}")
	public ResponseEntity<Reviews> deleteReview(@PathVariable("productId")int productId,@PathVariable("reviewId")int reviewId) {
		if(reviewService.isReviewExists(productId,reviewId))
		{
			reviewService.deleteReviews(productId, reviewId);
		return new ResponseEntity<Reviews>(HttpStatus.OK);
		}
		else {
			return new ResponseEntity<Reviews>(HttpStatus.NOT_FOUND);
		}
	}
	
	//updating reviews
	@PutMapping("/{productId}/reviews")
	public ResponseEntity<Reviews> updateReview(@PathVariable("productId")int productId,@RequestBody Reviews review) {
		System.out.println("Updating Reviews called");
		if(reviewService.isReviewExists(review.getReviewId(), productId))
		{
			reviewService.updateReviews(productId, review);
			return new ResponseEntity<Reviews>(HttpStatus.OK);
		}
		else {
			return new ResponseEntity<Reviews>(HttpStatus.NOT_FOUND);
		}
	}
	
}
