import React, { Component } from 'react';
import ListProductComponent from './Component/ListProductComponent';
import './App.css';
import 'bootstrap/dist/css/bootstrap.css';
import {Switch,Route} from 'react-router-dom';
import {BrowserRouter as Router} from 'react-router-dom';
import ProductComponent from './Component/ProductComponent';
import SearchComponent from './Component/SearchComponent';
import ProductsByName from './Component/ProductsByName';
//@import url(https://unpkg.com/bootstrap@4.1.0/dist/css/bootstrap.min.css) in App.css

class App extends Component {
  render() {
    return (
      <div>
        <h1>Welcome to Product App</h1>
        <Router>
        <Switch>
          <Route path="/" exact component={ListProductComponent}/>
          <Route path="/products" exact component={ListProductComponent}/>
          <Route path="/products/:prodId" exact component={ProductComponent}/>
          <Route path="/product/Search" exact component={SearchComponent}/>
          <Route path="/product/Search/:searchName" exact component={ProductsByName}/>
        </Switch>
        </Router>
      </div>
    );
  }
}

export default App;