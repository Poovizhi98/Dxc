import React, { Component } from 'react';
import ProductDataService from '../Service/ProductDataService';
import { Formik, Form, Field, ErrorMessage } from 'formik';

class ProductComponent extends Component {
    constructor(props) {
        super(props);
        this.state=({
            productId:this.props.match.params.prodId,
            productName:'',
            quantityOnHand:'',
            price:'',
            buttonName:'Update',
            disabled:true
        })
        this.onSubmit=this.onSubmit.bind(this);
    }
    componentWillMount(){
        if(this.state.productId==-1)
        {
            this.setState({
                buttonName:'Save',
                disabled:false
            })
        
        return;
        }
        else{
        ProductDataService.getProduct(this.state.productId).then(
            response=>{
                this.setState({
                    productName:response.data.productName,
                    quantityOnHand:response.data.quantityOnHand,
                    price:response.data.price
                })
            }
        )
        }
    }

    onSubmit(product){
       console.log(product);
       if(product.productId==-1)
       ProductDataService.saveProduct(product).then((response)=>this.props.history.push(`/products`))
       else
       ProductDataService.updateProduct(product).then((response)=>this.props.history.push(`/products`))
    }
    validateProductForm(values){
    let errors={}
    if(!values.productId)
    {
        errors.productId='Enter productId'
    }
    else if(!values.productName){
        errors.productName='Enter product Name'
    }
    else if(values.productName.length<3){
        errors.productName='Length of productName should be greater than 3'
    }
    else if(!isNaN(values.productName)){
        errors.productName='ProductName should not be integer'
    }
    else if(!values.quantityOnHand){
        errors.quantityOnHand='Enter quantity on Hand'
    }
    else if(!values.price){
        errors.price='Enter price'
    }
    else if(values.price<0){
        errors.price='Price should not be negative'
    }
    return errors
    }

    render() {
        
        let {productId,productName,quantityOnHand,price}=this.state
        return (
            <div>
                <h3>Add/Update Products</h3>
        {/* <h3>Update Product Id:</h3>
    <h4>{productId}</h4>
        <h4>{productName}</h4>
    <h4>{quantityOnHand}</h4>
        <h4>{price}</h4> */}
        <div className="container">
        <Formik initialValues={{productId,productName,quantityOnHand,price}}
         enableReinitialize={true} onSubmit={this.onSubmit} validateOnChange={false}
         validateOnBlur={false} validate={this.validateProductForm}>
            <Form>
                <ErrorMessage name="productId" component="div" className="alert alert-warning"></ErrorMessage>
                <fieldset className="form-group">
                    <label>Product Id</label>
                    <Field className="form-control"
                    type="text" name="productId" disabled={this.state.disabled}></Field>
                </fieldset>
                <ErrorMessage name="productName" component="div" className="alert alert-warning"></ErrorMessage>
                <fieldset className="form-group">
                    <label>Product Name</label>
                    <Field className="form-control"
                    type="text" name="productName"></Field>
                </fieldset>
                <ErrorMessage name="quantityOnHand" component="div" className="alert alert-warning"></ErrorMessage>
                <fieldset className="form-group">
                    <label>Quantity On Hand</label>
                    <Field className="form-control"
                    type="text" name="quantityOnHand"></Field>
                </fieldset>
                <ErrorMessage name="price" component="div" className="alert alert-warning"></ErrorMessage>
                <fieldset className="form-group">
                    <label>Price</label>
                    <Field className="form-control"
                    type="text" name="price"></Field>
                </fieldset>
    <button className="btn btn-success" type="submit">{this.state.buttonName}</button>
            </Form>
        </Formik>
        </div>
            </div>
        );
    }
}

export default ProductComponent;