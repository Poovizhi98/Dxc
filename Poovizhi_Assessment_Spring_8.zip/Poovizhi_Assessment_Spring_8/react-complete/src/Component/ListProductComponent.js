import React, { Component } from 'react';
import ProductDataService from '../Service/ProductDataService';

class ListProductComponent extends Component {

    constructor(props) {
        super(props);
        this.refreshProduct=this.refreshProduct.bind(this);
        this.deleteButtonClicked=this.deleteButtonClicked.bind(this);
        this.updateProductClicked=this.updateProductClicked.bind(this);
        this.addProductClicked=this.addProductClicked.bind(this);
        this.state=({
            products:[],
            message:''
        })
    }
    
    componentWillMount(){
        this.refreshProduct();
    }
    refreshProduct(){
        ProductDataService.getAllProducts().then(
            response=>{
                this.setState({
                    products:response.data
                })
            }
        )
    }
    deleteButtonClicked(productIdtoDelete){
        ProductDataService.deleteProduct(productIdtoDelete).then(
            response=>{
                this.setState({
                    message:'Product Id '+productIdtoDelete+' deleted successfully!'
                })
                this.refreshProduct();
            }
        )
    }
    updateProductClicked(productId){
       this.props.history.push(`/products/${productId}`)
    }
    addProductClicked(productId){
    this.props.history.push(`/products/${productId}`)
    }
    ButtonClicked(){
        this.props.history.push(`/product/Search`)
    }
    render() {
        return (
            <div>
             <div className="container">
                 {this.state.message && <div className="alert alert-warning">{this.state.message}</div>}
               <h2>All products</h2>
               <div className="container">
                   <table className="table">
                      <thead>
                          <tr>
                          <th>ProductId</th>
                          <th>ProductName</th>
                          <th>QuantityOnHand</th>
                          <th>Price</th>
                          <th>Delete</th>
                          <th>Update</th>
                          </tr>
                      </thead>
                      <tbody>
                          {
                          this.state.products.map(product=>
                        <tr key={product.productId}>
                          <td>{product.productId}</td>
                          <td>{product.productName}</td>
                          <td>{product.quantityOnHand}</td>
                          <td>{product.price}</td>
                          <td>
                              <button className="btn btn-danger" onClick=
                              {()=>this.deleteButtonClicked(product.productId)}>
                              Delete
                            </button>
                          </td>
                          <td>
                              <button className="btn btn-warning" onClick=
                              {()=>this.updateProductClicked(product.productId)}>
                              Update
                            </button>
                          </td>
                        </tr>
                        )}
                        </tbody> 
                   </table>
                   <button className="btn btn-success" onClick=
                      {()=>this.addProductClicked(-1)}>Add</button><pre></pre>
                    <button className="btn btn-success" onClick=
                    {()=>this.ButtonClicked()}>Search</button>
               </div>
            </div> 
            </div>
        );
    }
}

export default ListProductComponent;