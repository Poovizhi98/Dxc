import React, { Component } from 'react';
import '../App.css';
import ProductDataService from '../Service/ProductDataService';
class ProductsByName extends Component {
        constructor(props) {
        super(props);
        this.state=({
            products:[],
            productName:this.props.match.params.searchName, 
        })
        this.ButtonClicked=this.ButtonClicked.bind(this)
    }
    componentWillMount()
    {
            ProductDataService.getProductByName(this.state.productName).then(
                response =>{
                    this.setState({
                        products:response.data
                    })
                    }
                
            )
            }
            ButtonClicked(){
                this.props.history.push(`/products`)
            }
    render() {

        return (
            <div>             
                <div className="container">
                <h1>Searched Product</h1>
                        <table className="table">
                            <thead>
                            <tr>
                                <th>Product Id</th>
                                <th>Product Name</th>
                                <th>Quantity On Hand</th>
                                <th>Price</th>     
                            </tr>
                            </thead>
                            <tbody>
                            {
                                this.state.products.map(product=>
                                    <tr key={product.productId}>
                                        <td>{product.productId}</td>
                                        <td>{product.productName}</td>
                                        <td>{product.quantityOnHand}</td>
                                        <td>{product.price}</td>
                                          </tr>
                                    
                                    )
                            }
                            </tbody>
                            </table>
                            <button className="btn btn-warning" onClick={()=>this.ButtonClicked()}>Back</button>
                        
                </div>
        </div>
            
            
        );
    }
}

export default ProductsByName;