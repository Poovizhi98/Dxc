package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.model.Product;
import com.service.ProductService;

@RestController
@RequestMapping("product")
@CrossOrigin(origins= {"http://localhost:3000","http://localhost:4200"})
public class MyFirstController {

//	@RequestMapping("/neha")
//	public String abc() {
//		return "watch";
//	}
//	
//	@RequestMapping("/jay")
//	public String abc1() {
//		return "cool";
//	}
	
	@Autowired
	ProductService productService;
	
	//Getting a Product by ProductId
	@GetMapping("/{productId}")
	public ResponseEntity<Product> getProduct1(@PathVariable("productId")int productId) {
		System.out.println("Get Products  called "+productId);
		Product product=new Product();
		if(productService.isProductExists(productId))
		{
		product= productService.getProduct(productId);
		return new ResponseEntity<Product>(product,HttpStatus.OK);
		}
		else {
			return new ResponseEntity<Product>(product,HttpStatus.NO_CONTENT);
		}
	}
	
	//Getting all the products
	@GetMapping
	public ResponseEntity<List<Product>> getAllProducts() {
		System.out.println("Get All products called");
		List<Product>allproducts= productService.getAllProducts();
		return new ResponseEntity<List<Product>>(allproducts,HttpStatus.OK);
	}
	
	//Deleting the product by ProductId
	@DeleteMapping("/{productId}")
	public ResponseEntity<Product> deleteProduct(@PathVariable("productId")int productId) {
		if(productService.isProductExists(productId))
		{
		productService.deleteProduct(productId);
		return new ResponseEntity<Product>(HttpStatus.OK);
		}
		else {
			return new ResponseEntity<Product>(HttpStatus.NOT_FOUND);
		}
	}
	
	//Saving the Product
	@PostMapping
	public ResponseEntity<Product> saveProduct(@RequestBody Product product) {
		System.out.println("Saving Products called");
		if(productService.isProductExists(product.getProductId()))
		{
			return new ResponseEntity<Product>(HttpStatus.CONFLICT);
		}
		else {
			productService.addProduct(product);
			return new ResponseEntity<Product>(HttpStatus.CREATED);
		 
		}
	}
	
	//Updating the products
	@PutMapping
	public ResponseEntity<Product> updateProduct(@RequestBody Product product) {
		System.out.println("Updating Products called");
		if(productService.isProductExists(product.getProductId()))
		{
			productService.updateProduct(product);
			return new ResponseEntity<Product>(HttpStatus.OK);
		}
		else {
			return new ResponseEntity<Product>(HttpStatus.NOT_FOUND);
		}
	}
	
	@GetMapping("/Search/{productName}")
	public ResponseEntity<List<Product>> getProductByName(@PathVariable("productName")String productName) {
		System.out.println("Get Products  called "+productName);
		List<Product> product;
//		if(productService.isProductExists(productId))
//		{
		product= productService.searchProductByName(productName);
		return new ResponseEntity<List<Product>>(product,HttpStatus.OK);
//		}
//		else {
//			return new ResponseEntity<Product>(product,HttpStatus.NO_CONTENT);
//		}
	}
	
//	@RequestMapping("/getProduct/{productId}/orders/{oId}")
//	public Product getProduct2(@PathVariable("productId")int productId,@PathVariable("oId")int orderId)
//	{
//		System.out.println("Get Products 2 called with productId "+productId+" and orderId "+orderId);
//		return productService.getProduct(productId);
//	}

//	@RequestMapping("/productSave")
//	public ModelAndView productSave(Product product)
//	{
//		System.out.println("Inside Controller"+product);
//		productService.addProduct(product);
//		System.out.println(product);
//		return new ModelAndView("success","p",product);
//	}
}
