import React, { Component } from 'react';

class Customer extends Component {
    render() {
        return (
            <div>
                <h1>Customer Component</h1>
            </div>
        );
    }
}

export default Customer;