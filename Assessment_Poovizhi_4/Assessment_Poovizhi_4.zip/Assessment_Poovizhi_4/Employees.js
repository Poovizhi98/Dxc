import React, { Component } from 'react';

class Employees extends Component {
    render() {
        return (
            <div>
                <h1>Employee Component</h1>
            </div>
        );
    }
}

export default Employees;