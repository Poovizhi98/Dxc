package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.model.Movies;
import com.service.MoviesService;

@RestController
@RequestMapping("movies")
public class MoviesController {
	
	@Autowired
	MoviesService moviesService;

	//Adding the move
	@PostMapping
	public boolean addMovie(@RequestBody Movies movie) {
		System.out.println(movie);
		return moviesService.addMovie(movie);
	}
	
	//Get the movie by movieId
	@GetMapping("/{movieId}")
	public Movies getMovie(@PathVariable("movieId")int movieId) {
		System.out.println("Get Movies called");
		return moviesService.getMovie(movieId);
	}
	
	//Updating the movie
	@PutMapping
	public boolean updateMovie(@RequestBody Movies movie) {
		System.out.println(movie);
		return moviesService.updateMovie(movie);
	}
	
	//Get all the movies
	@GetMapping
	public List<Movies> getAllMovies() {
		System.out.println("Get All Movies called");
		return moviesService.getAllMovies();
	}

	//Deleting the movie 
	@DeleteMapping("/{movieId}")
	public boolean deleteMovies(@PathVariable("movieId")int movieId) {
		return moviesService.deleteMovie(movieId);
		
	}
}
