package com.dao;

import java.util.List;

import com.model.Movies;

public interface MoviesDAO {
   public boolean addMovie(Movies movie);
   public Movies getMovie(int movieId);
   public boolean isMovieExists(int movieId);
   public boolean deleteMovie(int movieId);
   public boolean updateMovie(Movies movie);
   public List<Movies> getAllMovies();
   public List<Movies> searchMovieByName(String movieName);
}
