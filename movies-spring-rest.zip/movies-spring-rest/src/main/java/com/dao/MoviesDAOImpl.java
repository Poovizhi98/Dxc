package com.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.model.Movies;
import com.mongodb.WriteResult;

@Repository
public class MoviesDAOImpl implements MoviesDAO {

	@Autowired
	MongoTemplate mongoTemplate;
	MoviesDAO moviesDAO;
	@Override
	public boolean addMovie(Movies movie) {
		// TODO Auto-generated method stub
		mongoTemplate.save(movie);
		return false;
	}

	@Override
	public Movies getMovie(int movieId) {
		// TODO Auto-generated method stub
		return mongoTemplate.findById(movieId, Movies.class,"movie");
	}

	@Override
	public boolean isMovieExists(int movieId) {
		// TODO Auto-generated method stub
		Movies movie=mongoTemplate.findById(movieId, Movies.class,"movie");
		if(movie==null)
		    return false;
		else
			return true;
	}

	@Override
	public boolean deleteMovie(int movieId) {
		// TODO Auto-generated method stub
		Movies movie=new Movies();
		movie.setMovieId(movieId);
		WriteResult writeResult=mongoTemplate.remove(movie);
		System.out.println(writeResult);
		int rowsAffected=writeResult.getN();
		if(rowsAffected==0)
		return false;
		else
			return true;
	}

	@Override
	public boolean updateMovie(Movies movie) {
		// TODO Auto-generated method stub
		mongoTemplate.save(movie);
		return false;
	}

	@Override
	public List<Movies> getAllMovies() {
		// TODO Auto-generated method stub
		mongoTemplate.findAll(Movies.class);
		return null;
	}

	@Override
	public List<Movies> searchMovieByName(String movieName) {
		// TODO Auto-generated method stub
		return null;
	}

}
