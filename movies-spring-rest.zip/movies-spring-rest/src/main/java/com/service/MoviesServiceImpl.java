package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.MoviesDAO;
import com.model.Movies;

@Service
public class MoviesServiceImpl implements MoviesService {

	@Autowired
	MoviesDAO moviesDAO;
	@Override
	public boolean addMovie(Movies movie) {
		// TODO Auto-generated method stub
		return moviesDAO.addMovie(movie);
	}

	@Override
	public Movies getMovie(int movieId) {
		// TODO Auto-generated method stub
		return moviesDAO.getMovie(movieId);
	}

	@Override
	public boolean isMovieExists(int movieId) {
		// TODO Auto-generated method stub
		return moviesDAO.isMovieExists(movieId);
	}

	@Override
	public boolean deleteMovie(int movieId) {
		// TODO Auto-generated method stub
		return moviesDAO.deleteMovie(movieId);
	}

	@Override
	public boolean updateMovie(Movies movie) {
		// TODO Auto-generated method stub
		return moviesDAO.updateMovie(movie);
	}

	@Override
	public List<Movies> getAllMovies() {
		// TODO Auto-generated method stub
		return moviesDAO.getAllMovies();
	}

	@Override
	public List<Movies> searchMovieByName(String movieName) {
		// TODO Auto-generated method stub
		return moviesDAO.searchMovieByName(movieName);
	}

}
