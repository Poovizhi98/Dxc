package com.dxc.pms.dao;

import java.util.List;
import java.util.Set;

import javax.persistence.criteria.CriteriaBuilder;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.CriteriaDefinition;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import com.dxc.pms.model.Product;
import com.dxc.pms.model.Review;
import com.dxc.pms.service.ProductService;

import com.mongodb.WriteResult;


@Repository
public class ReviewDAOImpl implements ReviewDAO {
	
	@Autowired
	MongoTemplate mongoTemplate;
	
	@Autowired
	ProductService productService;

	@Override
	public boolean addReview(Review review,int productId) {
		Product product=productService.getProduct(productId);
		System.out.println(product);
		//List<Reviews> r=(List<Reviews>) product.getReviews();
		//r.add(review);
		product.getProductReview().add(review);
		mongoTemplate.save(product);
		//mongotemplate.save(review);
		return false;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Set<Review> getAllReview(int productId) {
		
		Product product=productService.getProduct(productId);
		Set<Review> r= product.getProductReview();
		return r;
	}
	
	

	
	@Override
	public boolean isReviewExists(int reviewId, int productId) {
		Product product=productService.getProduct(productId);
		Set<Review> r=product.getProductReview();
		for(Review x:r) {
            if(x.getReviewId()==reviewId) {
            	System.out.println("if enetred");
                return true;
            }
        }
		return false;
	}

	
	@Override
	public Review getReview(int reviewId, int productId) {
		Product product=productService.getProduct(productId);
		System.out.println(product);
		
		Set<Review> r=product.getProductReview();
		System.out.println(r);
		for(Review x:r) {
			if(x.getReviewId()==reviewId) {
				return x;
			}
		}
		return null;
	}

	@Override
	public boolean deleteReview(int reviewId, int productId) {
		Product product=productService.getProduct(productId);
		System.out.println(product);
		Set<Review> r=product.getProductReview();
		System.out.println(r);
		for(Review x:r) {
			if(x.getReviewId()==reviewId)
			{
				
				r.remove(x);
				product.setProductReview(r);
				mongoTemplate.save(product);
			}
			
		}
		return false;
	}

	@Override
	public boolean updateReview(int productId, Review review) {
		Query query=new Query();
		query.addCriteria(new Criteria().andOperator(Criteria.where("_id").is(productId),
				Criteria.where("reviewId").is(review.getReviewId())));
		Product product=productService.getProduct(productId);
		Set<Review> r=product.getProductReview();
		for(Review x:r) {
			if(x.getReviewId()==review.getReviewId())
			{
				
				r.remove(x);
				r.add(review);
				product.setProductReview(r);
				mongoTemplate.save(product);
				return true;
			}
			
		}
		return false;
		
	}
	

	

}
