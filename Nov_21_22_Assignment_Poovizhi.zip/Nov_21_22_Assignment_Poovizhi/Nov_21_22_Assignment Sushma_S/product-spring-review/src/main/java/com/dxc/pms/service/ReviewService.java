package com.dxc.pms.service;

import java.util.List;
import java.util.Set;

import com.dxc.pms.model.Product;
import com.dxc.pms.model.Review;

public interface ReviewService {

	public boolean addReview(Review review,int productId);
	
	public Set<Review> getAllReview(int productId);

	public boolean deleteReview(int reviewId, int productId);

	public boolean isReviewExists(int productId, int reviewId);

	public Review getReview(int productId, int reviewId);

	public boolean updateReview(int productId, Review review);
	

}
