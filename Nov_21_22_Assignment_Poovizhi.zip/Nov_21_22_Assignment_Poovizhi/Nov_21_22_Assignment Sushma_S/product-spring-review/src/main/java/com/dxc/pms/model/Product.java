package com.dxc.pms.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Entity
public class Product {
	
    @Id
   
	private int productId;
	private String productName;
	private int quantityOnHand;
	private int price;
	 @OneToMany
	 private Set<Review> productReview = new HashSet<Review>();
	

	public Product() {
		// TODO Auto-generated constructor stub
	}


	public Product(int productId, String productName, int quantityOnHand, int price, Set<Review> productReview) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.quantityOnHand = quantityOnHand;
		this.price = price;
		this.productReview = productReview;
	}


	public int getProductId() {
		return productId;
	}


	public void setProductId(int productId) {
		this.productId = productId;
	}


	public String getProductName() {
		return productName;
	}


	public void setProductName(String productName) {
		this.productName = productName;
	}


	public int getQuantityOnHand() {
		return quantityOnHand;
	}


	public void setQuantityOnHand(int quantityOnHand) {
		this.quantityOnHand = quantityOnHand;
	}


	public int getPrice() {
		return price;
	}


	public void setPrice(int price) {
		this.price = price;
	}


	public Set<Review> getProductReview() {
		return productReview;
	}


	public void setProductReview(Set<Review> productReview) {
		this.productReview = productReview;
	}


	


	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", quantityOnHand=" + quantityOnHand
				+ ", price=" + price + ", productReview=" + productReview + "]";
	}

	

	
	
}
