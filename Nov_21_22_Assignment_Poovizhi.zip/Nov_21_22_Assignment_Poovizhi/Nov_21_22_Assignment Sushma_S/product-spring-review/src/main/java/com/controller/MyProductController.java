package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dxc.pms.model.Product;
import com.dxc.pms.service.ProductService;

@RestController
@RequestMapping("product")
@CrossOrigin(origins= {"http://localhost:3000"}) //default port number for react.. cors policy..spring has o allow for access in react
public class MyProductController {
	 
	@Autowired
	ProductService productService;
	
	@GetMapping
	public ResponseEntity<List<Product>> getProducts()
	{
		System.out.println("get all product called");
		List<Product> allProducts=productService.getAllProducts();
		return new ResponseEntity<List<Product>>(allProducts, HttpStatus.OK);
	}
	
	
	
	@GetMapping("/{productId}") 
	public ResponseEntity<Product> getProduct(@PathVariable("productId")int productId) {
	  System.out.println("get product called with "+productId ); 
	  Product product=new Product();
	  if(productService.isProductExists(productId)) {
		  product=productService.getProduct(productId);
		  return new ResponseEntity<Product>(product,HttpStatus.OK);//200
	  }
	  else {
		  return new ResponseEntity<Product>(product,HttpStatus.NO_CONTENT);
	  }
	  
	 }
	
	
	
	@DeleteMapping("/{productId}")
	public ResponseEntity<String> deleteProduct(@PathVariable("productId")int productId)
	{
		System.out.println("delete product called with"+productId );
		if(productService.isProductExists(productId)) {
			  productService.deleteProduct(productId);
			  return new ResponseEntity<String>("Product is deleted successsfully",HttpStatus.NO_CONTENT);
		  }
		  else {
			  return new ResponseEntity<String>("not found",HttpStatus.NOT_FOUND);//204
		  }
	}
	
	@PostMapping
	public ResponseEntity<Product> saveProduct(@RequestBody Product product) //requestbody : instead of wrtitng all parameters in url
	{
		System.out.println("saving with"+product);
		
		if(productService.isProductExists(product.getProductId())) {
			return new ResponseEntity<Product>(product,HttpStatus.CONFLICT);//409
		}
		else {
			productService.addProduct(product);
			return new ResponseEntity<Product>(product,HttpStatus.CREATED);//201
			
		}
		
	}
	
	@PutMapping
	public ResponseEntity<Product> updateProduct(@RequestBody Product product) //requestbody : instead of wrtitng all parameters in url
	{
		System.out.println("update with"+product);
		
		if(productService.isProductExists(product.getProductId())) {
			  productService.updateProduct(product);
			  return new ResponseEntity<Product>(product,HttpStatus.OK);
		  }
		  else {
			  return new ResponseEntity<Product>(product,HttpStatus.NO_CONTENT);
		  }	
	}
	
	@GetMapping("/searchProduct/{productName}") 
	  public ResponseEntity<List<Product>>getProductByName(@PathVariable("productName")String productName){
	  System.out.println("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%searchproduct by name"); 
	  List<Product> allProducts=productService.getProductByName(productName);
	  System.out.println(allProducts);
		return new ResponseEntity<List<Product>>(allProducts, HttpStatus.OK);
	 }
	
	
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*
	 * @RequestMapping("/getProduct/{productId}") public Product
	 * getProduct1(@PathVariable("productId")int productId) {
	 * System.out.println("get product1 called"+productId); return
	 * productService.getProduct(12); }
	 * 
	 * @RequestMapping("/getProduct/pp") public Product getProduct2() { //u get json
	 * page System.out.println("get product 2 called"); return
	 * productService.getProduct(12); }
	 * 
	 * @RequestMapping("/getProduct/{pId}/order/{oId}") public Product
	 * getProduct(@PathVariable("pId")int productId,@PathVariable("oId")int orderId)
	 * { System.out.println("get prdouct 3 called"+productId+"order"+orderId);
	 * return productService.getProduct(12); }
	 */
	

	


