import React, { Component } from 'react';
import ListProductComponent from './component/ListProductComponent';
//import 'bootstrap/dist/css/bootstrap.css'
import './App.css'
import {Switch,Route} from 'react-router-dom'
import {BrowserRouter as Router} from 'react-router-dom'
import ProductComponent from './component/ProductComponent';
import searchProductComponent from './component/searchProductComponent';
import ReviewComponent from './component/ReviewComponent';


class App extends Component {
  render() {
    return (
      <div>
        <h1>My Product App</h1> 
        <Router>
          <Switch>
            <Route exact path="/" component={ListProductComponent}/>
            <Route exact path="/products" component={ListProductComponent}/>
            <Route exact path="/products/:prodId" component={ProductComponent}/>
            <Route exact path="/addProducts" component={ProductComponent}/>
            <Route exact path="/searchProducts" component={searchProductComponent}/>
            <Route exact path="/productsNameList/:productName" component={ListProductComponent}/>
            <Route exact path="/addReview/:productId" component={ReviewComponent}/>
            <Route exact path="/updateReview/:productId/review/:reviewId" component={ReviewComponent}/>
            </Switch>
        </Router>       
        {/* <ListProductComponent></ListProductComponent> */}
        </div>      
    );
  }
}

export default App;

