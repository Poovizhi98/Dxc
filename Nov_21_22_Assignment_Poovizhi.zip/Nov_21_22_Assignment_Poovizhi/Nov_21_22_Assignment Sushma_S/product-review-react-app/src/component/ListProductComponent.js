import React, { Component } from 'react';
import ProductDataService from '../service/ProductDataService';

class ListProductComponent extends Component {

    constructor(props) {
        super(props);
        this.state={
            products:[],
            reviews:[],
            message:'',
            productName:this.props.match.params.productName,

           
        }
        this.refreshProduct=this.refreshProduct.bind(this);
        this.deleteProuctClicked=this.deleteProductClicked.bind(this);
        this.addProductClicked=this.addProductClicked.bind(this);
        this.updateProductClicked=this.updateProductClicked.bind(this);
        this.searchProductClicked=this.searchProductClicked.bind(this);
        this. addReviewClicked=this. addReviewClicked.bind(this);
        this.deleteReviewClicked=this.deleteReviewClicked.bind(this);
        this.updateReviewClicked=this.updateReviewClicked.bind(this)
    }
    
    componentWillMount()
    { //will get called before rendering
        this.refreshProduct()
    }
    refreshProduct()
    {
        if(this.state.productName)
        {
            ProductDataService.getProductByName(this.state.productName).then(
                response=>{
                    this.setState({
                        products:response.data
                        
                    })
                  
                })          
        }
        else{
            ProductDataService.getAllProducts().then(
                response=>{
                    this.setState({
                        products:response.data
                        
                    })

                })
        }                
    }
    deleteProductClicked(productIdToDelete)
    {
        ProductDataService.deleteProduct(productIdToDelete).then(
            response=>{
                this.setState({
                    message:"product Id "+productIdToDelete+" deleted successfully"
                })
                this.refreshProduct();
            }
            )
    }
    addProductClicked()
    {
        this.props.history.push(`/addProducts`)
    }
    updateProductClicked(productId)
    {
        this.props.history.push(`/products/${productId}`)
    }
    searchProductClicked()
    {
        this.props.history.push(`/searchProducts/`)
    }
    addReviewClicked(productId){
        this.props.history.push(`/addReview/${productId}`)
    }
    deleteReviewClicked(productId,reviewId)
    {
        console.log(productId+",,,"+reviewId)
        ProductDataService.deleteReview(productId,reviewId).then(response=>{
            this.setState({
                message:"review Id "+reviewId+" deleted successfully"
            })
            this.refreshProduct();
        })
    }
    updateReviewClicked(productId,reviewId)
    {
        
        this.props.history.push(`/updateReview/${productId}/review/${reviewId}`)
    }

    render() {
        return (
            <div>
                <div className="container">
                
                 <h2>All Products</h2>
                 {this.state.message && <div className="alert alert-danger">{this.state.message}</div>}
                 <div className="container">
                     <table className="table">
                         <thead>
                             <tr>
                             <th>Product Id</th>
                             <th>Product Name</th>
                             <th>Quantity On Hand</th>
                             <th>Price</th>
                             <th>Review</th>
                             <th>Delete</th>
                             <th>Update</th>
                             
                        
                             </tr>
                         </thead>
                         <tbody>
                            
                                  {this.state.products.map(product=>
                                  
                                      <tr key={product.productId}>
                                    <td>{product.productId}</td>
                                    <td>{product.productName}</td>
                                    <td>{product.quantityOnHand}</td>
                                    <td>{product.price}</td>
                                    <td>
                                            <table>
                                                <thead>
                                                    <th>Review Id</th>
                                                    <th>Review Text</th>
                                                    <th>Rating</th>
                                                    <th>Update</th>
                                                    <th>Delete</th>
                                                </thead>
                                                <tbody>
                                                    {product.productReview && product.productReview.map(r=>
                                                    <tr>
                                                        <td>{r.reviewId}</td>
                                                        <td>{r.reviewText}</td>
                                                        <td>{r.reviewRating}</td>
                                                        <td><button className="btn btn-danger "
                                    onClick={()=>this.deleteReviewClicked(product.productId,r.reviewId)}>Delete</button></td>
                                    <td><button className="btn btn-warning "
                                    onClick={()=>this.updateReviewClicked(product.productId,r.reviewId)}>Update</button></td>
                                                    </tr>)}
                                                </tbody>

                                            </table>
                                            <button className="btn btn-warning btn-group btn-group-md col-md-offset-3 "
                     onClick={()=>this.addReviewClicked(product.productId)}>Add Review</button>
                                        </td>
                                   
                                    
                                    <td><button className="btn btn-danger "
                                    onClick={()=>this.deleteProductClicked(product.productId)}>Delete</button></td>
                                    <td><button className="btn btn-warning "
                                    onClick={()=>this.updateProductClicked(product.productId)}>Update</button></td>
                                    </tr>  
                                 )} 
                                 
                                    


                             </tbody>                         
                    </table>
                     <button className="btn btn-warning btn-group btn-group-md col-md-offset-3 "
                     onClick={()=>this.addProductClicked()}>Add Product</button>
                     <button className="btn btn-success btn-group btn-group-md col-md-offset-3"
                     onClick={()=>this.searchProductClicked()}>Search Product by Name</button>
                     
                 </div> 
                </div>
            </div>
        );
    }
}
export default ListProductComponent;