package com.service;

import java.util.List;

import com.model.Reviews;

public interface ReviewService {
	public boolean addReviews(Reviews review);
    public Reviews getReviews(int reviewId);
    public boolean isReviewExists(int reviewId);
    public boolean deleteReviews(int reviewId);
    public boolean updateReviews(Reviews review);
    public List<Reviews> getAllReviews();
}
