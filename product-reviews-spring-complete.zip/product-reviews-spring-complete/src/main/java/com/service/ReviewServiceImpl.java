package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.ReviewDAO;
import com.model.Reviews;

@Service
public class ReviewServiceImpl implements ReviewService {

	@Autowired
	ReviewDAO reviewDAO;
	@Override
	public boolean addReviews(Reviews review) {
		// TODO Auto-generated method stub
		return reviewDAO.addReviews(review);
	}
	@Override
	public Reviews getReviews(int reviewId) {
		// TODO Auto-generated method stub
		return reviewDAO.getReviews(reviewId);
	}
	@Override
	public boolean isReviewExists(int reviewId) {
		// TODO Auto-generated method stub
		return reviewDAO.isReviewExists(reviewId);
	}
	@Override
	public boolean deleteReviews(int reviewId) {
		// TODO Auto-generated method stub
		return reviewDAO.deleteReviews(reviewId);
	}
	@Override
	public boolean updateReviews(Reviews review) {
		// TODO Auto-generated method stub
		return reviewDAO.updateReviews(review);
	}
	@Override
	public List<Reviews> getAllReviews() {
		// TODO Auto-generated method stub
		return reviewDAO.getAllReviews();
	}
	
	
}
