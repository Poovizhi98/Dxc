package com.dao;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.BasicQuery;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import com.model.Product;
import com.model.Reviews;
import com.mongodb.WriteResult;

@Repository
public class ReviewDAOImpl implements ReviewDAO {

	@Autowired
	MongoTemplate mongotemplate;
	ReviewDAO reviewDAO;
	@Override
	public boolean addReviews(Reviews review) {
		// TODO Auto-generated method stub
		System.out.println("Inside DAOImpl"+review);
		mongotemplate.save(review);
		return false;
	}
	
	@Override
	public Reviews getReviews(int reviewId) {
		// TODO Auto-generated method stub
		return mongotemplate.findById(reviewId, Reviews.class, "review");
	}
	@Override
	public boolean isReviewExists(int reviewId) {
		// TODO Auto-generated method stub
		Reviews review=mongotemplate.findById(reviewId, Reviews.class, "review");
		if(review==null)
		    return false;
		else
			return true;
	}
	@Override
	public boolean deleteReviews(int reviewId)  {
		// TODO Auto-generated method stub
		Reviews review=new Reviews();
		review.setReviewId(reviewId);
		WriteResult writeResult=mongotemplate.remove(review);
		System.out.println(writeResult);
		int rowsAffected=writeResult.getN();
		if(rowsAffected==0)
		return false;
		else
			return true;
	}
	@Override
	public boolean updateReviews(Reviews review) {
		// TODO Auto-generated method stub
	    Query query=new Query();
	    query.addCriteria(Criteria.where("_id").is(review.getReviewId()));
	    
	    Update update =new Update();
	    update.set("reviews", review.getReviews());
	    update.set("rating", review.getRating());
	    
	    WriteResult writeResult=mongotemplate.updateFirst(query, update, Reviews.class);
	    System.out.println(writeResult);
	    int rowsAffected=writeResult.getN();
	    if(rowsAffected==0)
		return false;
	    else
	    	return true;
	}
	@Override
	public List<Reviews> getAllReviews()  {
	
		return mongotemplate.findAll(Reviews.class);
	}
	

}
