package com.dxc.pms.controller;

import static org.junit.Assert.*;

import java.util.HashSet;
import java.util.Set;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.dxc.model.Hospital;
import com.dxc.model.HospitalDetails;
import com.dxc.model.Movies;
import com.dxc.pms.dao.UserDaoImpl;
import com.dxc.pms.model.User;

public class Controller_UserTest {
UserDaoImpl daoImpl;
	@Before
	public void setUp() throws Exception {
		daoImpl=new UserDaoImpl();
	}
//
//	@After
//	public void tearDown() throws Exception {
//	}

	@Test
	public void testGetProduct() {
		User user=new User(200,"Ranjitha","ranjitha@gmail.com",4567890345,636906,"qwertyui");
		daoimpl.add;
		Movies movie1=impl.getMovie(27);
		assertNotNull(movie1);
		impl.deleteMovie(27);
		
	}

	@Test
	public void testDeleteUser() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetAllUsers() {
		fail("Not yet implemented");
	}

	@Test
	public void testSaveUser() {
		fail("Not yet implemented");
	}

	@Test
	public void testUpdateUser() {
		fail("Not yet implemented");
	}

	@Test
	public void testLogin() {
		fail("Not yet implemented");
	}

}
