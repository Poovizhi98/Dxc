package com.dxc1.usrval.model;

public class Training {
	private int SapId;
	private String EmployeeName;
	private String Stream;
	private int Percentage=0;
	
	
	public Training() {
		super();
	}


	public Training(int sapId, String employeeName, String stream, int percentage) {
		super();
		SapId = sapId;
		EmployeeName = employeeName;
		Stream = stream;
		Percentage = percentage;
	}


	public int getSapId() {
		return SapId;
	}


	public void setSapId(int sapId) {
		SapId = sapId;
	}


	public String getEmployeeName() {
		return EmployeeName;
	}


	public void setEmployeeName(String employeeName) {
		EmployeeName = employeeName;
	}


	public String getStream() {
		return Stream;
	}


	public void setStream(String stream) {
		Stream = stream;
	}


	public int getPercentage() {
		return Percentage;
	}


	public void setPercentage(int percentage) {
		Percentage = percentage;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((EmployeeName == null) ? 0 : EmployeeName.hashCode());
		result = prime * result + Percentage;
		result = prime * result + SapId;
		result = prime * result + ((Stream == null) ? 0 : Stream.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Training other = (Training) obj;
		if (EmployeeName == null) {
			if (other.EmployeeName != null)
				return false;
		} else if (!EmployeeName.equals(other.EmployeeName))
			return false;
		if (Percentage != other.Percentage)
			return false;
		if (SapId != other.SapId)
			return false;
		if (Stream == null) {
			if (other.Stream != null)
				return false;
		} else if (!Stream.equals(other.Stream))
			return false;
		return true;
	}


	@Override
	public String toString() {
		return "Training [SapId=" + SapId + ", EmployeeName=" + EmployeeName + ", Stream=" + Stream + ", Percentage="
				+ Percentage + "]";
	}
     
	

	
	
	

}
