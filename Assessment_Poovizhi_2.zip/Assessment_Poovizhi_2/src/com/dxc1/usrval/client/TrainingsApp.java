package com.dxc1.usrval.client;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.Scanner;

import com.dxc1.usrval.dao.TrainingsDAOImpl;
import com.dxc1.usrval.dao.TrainingsDAO;
import com.dxc1.usrval.model.Training;

public class TrainingsApp {
	 String UserName;
	 String Password;
	 TrainingsDAO trainingsDAO;

	public TrainingsApp() {
		this.trainingsDAO=new TrainingsDAOImpl();
	}
	
	public void LaunchTrainingsApp() {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Please enter User Name");
		UserName=scanner.next();
		System.out.println("Please enter Password");
		Password=scanner.next();
		if(trainingsDAO.isvalidate(UserName,Password))
		{	
			System.out.println("Welcome "+UserName);
			while(true)
			{
				System.out.println("M E N U");
				System.out.println("1.Display all training records");
				System.out.println("2.Display records one by one and print the percentage");
				System.out.println("3.E X I T");			
				System.out.println("Please enter choice between 1 to 3");
				int choice=scanner.nextInt();
				
				switch(choice) {
				case 1:
					System.out.println(trainingsDAO.getallfields());
					break;
				case 2:
					
					break;
				case 3:
					System.out.println("Thanks for using my trainings app");
					System.exit(0);
				}
			}

		
			
	        }
	else
		{
			System.out.println("Sorry, username or password cannot be authenticated");
		}
	}
}
