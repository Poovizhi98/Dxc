package com.dxc1.usrval.client;

import com.dxc1.usrval.client.TrainingsApp;

public class Main {
	
	public Main() {
		
	}
	public static void main(String[] args) {
		TrainingsApp app=new TrainingsApp();
		app.LaunchTrainingsApp();
		

	}


}
