package com.dxc1.usrval.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.dxc1.usrval.dbcon.DBConnection;
import com.dxc1.usrval.model.Training;
import com.dxc1.usrval.model.UserValidation;

public class TrainingsDAOImpl implements TrainingsDAO {
	public TrainingsDAOImpl() {
		// TODO Auto-generated constructor stub
	}

	Connection connection = DBConnection.getConnection();
	private static final String FETCH_DETAILS = "select * from usertable";
	private static final String FETCH_TRAINING_DETAILS = "select * from trainingstable";


	public boolean isvalidate(String UserName, String Password) {
		// TODO Auto-generated method stub
		// UserValidation uservalidation=new UserValidation();
		boolean validation = false;
		PreparedStatement statement;
		try {
			statement = connection.prepareStatement("select* from usertable u where UserName=? and Password=?");
			statement.setString(1, UserName);
			statement.setString(2, Password);
			ResultSet res = statement.executeQuery();
			if (res.next())
				validation = true;

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// statement.setInt(1, productId);

		return validation;
	}

	public List<Training> getallfields() {
		List<Training> allmarks = new ArrayList<Training>();
		try {
			Statement stat = connection.createStatement();
			ResultSet res = stat.executeQuery(FETCH_TRAINING_DETAILS);
			while (res.next()) {
				Training training = new Training();
				training.setSapId(res.getInt(1));
				training.setEmployeeName(res.getString(2));
				training.setStream(res.getString(3));
				training.setPercentage(res.getInt(4));
				allmarks.add(training);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return allmarks;

	}

	@Override
	public void getTrainingmarks() {
		// TODO Auto-generated method stub
		Training training = new Training();
		Statement stat;
		try {
			stat = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			ResultSet res = stat.executeQuery("FETCH_TRAINING_DETAILS");

			ResultSetMetaData rsmd = res.getMetaData();
			res.absolute(0);

			while (res.next()) {
				for (int i = 1; i <= rsmd.getColumnCount(); i++) {
					System.out.println(res.getString(i) + " ");
					System.out.println("Enter percentage to update");
				}

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	

	}

}
