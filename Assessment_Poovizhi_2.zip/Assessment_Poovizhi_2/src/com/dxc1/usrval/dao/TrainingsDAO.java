package com.dxc1.usrval.dao;
import java.util.List;

import com.dxc1.usrval.model.Training;
import com.dxc1.usrval.model.UserValidation;

public interface TrainingsDAO {
	public boolean isvalidate(String UserName,String Password);
	public List<Training> getallfields();
	public void getTrainingmarks(); 	
	

}
