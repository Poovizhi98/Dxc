import React, { Component } from 'react';
import '../Second.css'

class Dealer extends Component {
    render() {
        return (
            <div>
                <h1>Inside Dealer component</h1>
            </div>
        );
    }
}

export default Dealer;